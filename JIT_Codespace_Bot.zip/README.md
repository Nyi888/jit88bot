# AI Telegram Bot (Codespace-ready)

## วิธีใช้งานใน GitHub Codespaces

1. เปิดไฟล์ `.env.template` แล้วสร้าง `.env` พร้อมใส่ API Key
2. ติดตั้ง dependency:
   pip install -r requirements.txt
3. เริ่มรันบอท:
   bash start.sh
4. บอทจะทำงานใน background ตลอดเวลา (24/7)

> ระบบนี้พร้อมรันใน GitHub Codespace, Replit หรือ Render ได้ทันที
