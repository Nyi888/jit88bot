#!/bin/bash
nohup python3 telegram_bot.py &